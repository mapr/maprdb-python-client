
# A long value equal to the number of milliseconds in a second
MILLISECONDS_PER_SECOND = 1000

# A long value equal to the number of milliseconds in a minute.
MILLISECONDS_PER_MINUTE = 60 * MILLISECONDS_PER_SECOND

# A long value equal to the number of milliseconds in an hour.
MILLISECONDS_PER_HOUR = 60 * MILLISECONDS_PER_MINUTE

# A long value equal to the number of milliseconds in a day.
MILLISECONDS_PER_DAY = 24 * MILLISECONDS_PER_HOUR
