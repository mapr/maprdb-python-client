class FieldPatherrorListener:
    def __init__(self):
        pass
# TODO we need this?
